T = int(input())
for t in range(1, T+1):
    N = int(input())
    lst = [list(map(int, input().split())) for _ in range(N)]
    min_v = float('inf') # 보너스 스테이지의 최대값
    max_v = -float('inf') # 보너스 스테이지의 최소값
    for i in range(N):
        for j in range(N):
            sum_v = lst[i][j] # 풍선 점수 합계, 처음 터뜨린 풍선
            for k in range(1, lst[i][j]+1): # 처음 터뜨린 풍선 숫자만큼 점점 범위를 넓임
                for d1, d2 in [[-1, 0], [0, 1], [1, 0], [0, -1]]: # 상우하좌
                    x, y = i + (d1*k), j + (d2*k) # 4방향에 범위 곱함
                    if 0 <= x < N and 0 <= y < N: # 격자를 벗어나지 않았다면
                        sum_v += lst[x][y] # 해당 해당값을 더한다.
            if min_v > sum_v: # 점수 합계가 기존 최소값보다 낮으면
                min_v = sum_v # 최소값을 갱신
            if max_v < sum_v: # 점수 합계가 기존 최대값보다 높으면
                max_v = sum_v # 최대값을 갱신
    res = max_v - min_v # 보너스점수 = 최대값 - 최소값
    print(f'#{t} {res}')