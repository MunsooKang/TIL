T = int(input())
for t in range(1, T+1):
    N, M = map(int, input().split())
    lst = list(input().split())  # 덱 A
    qb = []  # 덱  B : 홀수카드만, 선입선출
    sc = []  # 덱 C : 짝수카드만, 후입선출
    bonus = 0  # +를 만나면 1씩 증가한다.
    for ls in lst: # 덱 A 에서 카드를 한장씩 꺼낸다.
        if ls == '+': # 꺼낸 카드가 + 라면
            bonus += 1 # 보너스를 1 더한다.
        else: # 아니라면(숫자라면)
            num = int(ls) + bonus # 숫자에 보너스를 더한다.
            if num % 2 == 0: # 숫자가 짝수라면
                sc.append(num) # 덱C에 넣는다.
            else: # 숫자가 홀수라면
                qb.append(num) # 덱 B에 넣는다.

    score = [] # 1부터 M 번째 까지의 점수를 순차대로 저장
    for _ in range(M): # 1번부터 M번까지 한명씩 점수를 계산한다.
        s = 0 # 초기값 0점
        if qb != []: # 덱 B가 비어있지 않으면
            s += qb.pop(0) # 덱 B의 맨 앞 한장을 꺼내고 해당 점수를 더한다.
        if sc != []: # 덱 C가 비어있지 않으면
            s += sc.pop() # 덱 C의 맨 뒤 한장을 꺼내고 해당 점수를 더한다.
        score.append(s) # 점수의 합을 score에 저장한다.
    print(f'#{t} {score[M-1]}') # score[M] = M 번째 사람의 점수
