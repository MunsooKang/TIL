T = int(input())
for t in range(1, T+1):
    N = int(input()) # 탁자의 길이 및 챌린지 수행 횟수
    lst = list(map(int, input().split())) # 탁자 위의 숫자
    point = 0 # 획득 점수
    for i in range(1, N+1): # 챌린지 횟수 N , 1번부터 N번까지 반복
        for j in range(N): # 튕기는 거리, 0부터 시작하고, 챌린지 횟수(i) 만큼 늘어난다.
            if 0 <= i*j < N: # 튕긴 거리가 탁자 안에 포함되면
                point += lst[i*j] # 탁자의 해당 지점 점수를 획득 점수에 더한다.
    if point <= 0: # 획득 점수가 0 이하인 경우는 0으로 출력
        point = 0
    print(f'#{t} {point}')