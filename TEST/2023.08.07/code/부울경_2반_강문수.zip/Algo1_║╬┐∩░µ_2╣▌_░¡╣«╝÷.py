T = int(input())
for t in range(1, T+1):
    N = int(input())
    r1, c1, r2, c2 = list(map(int, input().split())) # 평탄화 영역 좌표
    lst = [list(map(int, input().split())) for _ in range(N)] # 마당
    sum_high = 0 # 평단화 영역의 높이 값의 합
    for i in range(r2-r1+1):
        for j in range(c2-c1+1):
            sum_high += lst[i+r1][j+c1]
    area = (r2 - r1 + 1) * (c2 - c1 +1) # 영역의 칸 수
    avg = sum_high // area # 평균값( '//' 정수 연산으로 소수점 아래는 버림)
    cnt = 0 # 평탄화 작업 횟수
    finish = 0  # 평탄화 된 땅
    while finish != area : # 모든 땅이 평탄화 되면 반복문을 탈출
        finish = 0 # finish를 0으로 초기화
        for i in range(r2 - r1 + 1):
            for j in range(c2 - c1 + 1): # 평탄화 영역을 순회하며
                if lst[i+r1][j+c1] == avg: # 평탄화가 됬으면 finish에 1을 더한다
                    finish += 1
                elif lst[i+r1][j+c1] < avg: # 평균값보다 낮으면 높이를 1 올리고, 평탄화 횟수를 1 올린다.
                    lst[i + r1][j + c1] += 1
                    cnt += 1
                else:
                    lst[i + r1][j + c1] -= 1 # 평균값보다 높으면 높이를 1 내리고, 평탄화 횟수를 1 올린다.
                    cnt += 1
    print(f'#{t} {cnt}')
